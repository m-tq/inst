#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "使用方法: $0 <目标文件夹>"
    exit 1
fi

TARGET_DIR="$1"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 应用patch
find "$SCRIPT_DIR" -name "*.patch" | while read -r patch_file; do
    rel_path="${patch_file#$SCRIPT_DIR/}"
    rel_path="${rel_path%.patch}"
    target_file="$TARGET_DIR/$rel_path"
    
    mkdir -p "$(dirname "$target_file")"
    patch -N "$target_file" < "$patch_file" || echo "Warning: Patch failed for $rel_path"
done

# 复制新文件
find "$SCRIPT_DIR" -type f ! -name "*.patch" ! -name "*.sh" ! -name "*.txt" | while read -r file; do
    rel_path="${file#$SCRIPT_DIR/}"
    target_file="$TARGET_DIR/$rel_path"
    
    mkdir -p "$(dirname "$target_file")"
    cp "$file" "$target_file"
done

# 处理删除的文件
if [ -f "$SCRIPT_DIR/deleted_files.txt" ]; then
    while read -r file; do
        rm -f "$TARGET_DIR/$file"
    done < "$SCRIPT_DIR/deleted_files.txt"
fi
